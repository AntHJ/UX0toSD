
	- *RIGHT CLICK* the SD-FormatTool.bat file
	- select 'Run as administrator'
	  (if you get a security warning, click more info, Run anyway)

	- Select the location of the SD card you wish to blank
	- Confirm the card details
	  (if your card flags as fake, beware if you decide to continue)
	
	- The Automated process then begins


	*** Just for reference, The automated process is : ***
	
	  * Format Stage 1 initially does a basic format on the SD
	    and renames the card for eaasier access in the next stage
	  * the zzBlank.img then gets flashed to remove all partitions
	  * Format Stage 2 formats the card as exFat and uses the cards
	    detected size to determin the file allocation unit size